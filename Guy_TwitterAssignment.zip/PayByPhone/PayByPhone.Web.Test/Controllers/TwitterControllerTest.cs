﻿using System;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using PayByPhone.Controllers;
using Twitter.Repository;
using PayByPhone.Models;
using Moq;
using System.Collections.Generic;

namespace PayByPhone.Web.Test
{
    [TestClass]
    public class TwitterControllerTest
    {
        [TestMethod]
        public void Index_Get_RightViewData()
        {
            TwitterController tc = new TwitterController();
            ViewResult result = tc.Index() as ViewResult;
            Assert.AreEqual("Guy's accomplishment on the Twitter assignment.", result.ViewBag.Message);
        }

        [TestMethod]
        public void Guy_Get_RightUserModel()
        {
            var mock = new Mock<ITwitterRepository>();
            mock.Setup(p => p.Guy("@PayByPhone")).Returns(new TwitterUserModel()
            {
                ID = 1234,
                Name = "TestGuy",
                Location = "Canada"
            });
            TwitterController tc = new TwitterController(mock.Object);
            ViewResult result = tc.Guy() as ViewResult;
            Assert.AreEqual(1234, ((TwitterUserModel)result.Model).ID);
            Assert.AreEqual("TestGuy", ((TwitterUserModel)result.Model).Name);
            Assert.AreEqual("Canada", ((TwitterUserModel)result.Model).Location);
        }

        [TestMethod]
        public void AuthorizeGuy_Get_RedirectResult()
        {
            var mock = new Mock<ITwitterRepository>();
            mock.Setup(p => p.AuthorizeGuy()).Returns(new Uri(
                "https://api.twitter.com/oauth/authorize?oauth_token=vXni7WC6l37HpEAa0fjMUHN7zBsqmyBNZwJvLjpLkc"
            ));
            TwitterController tc = new TwitterController(mock.Object);
            RedirectResult result = tc.AuthorizeGuy() as RedirectResult;
            Assert.AreEqual("https://api.twitter.com/oauth/authorize?oauth_token=vXni7WC6l37HpEAa0fjMUHN7zBsqmyBNZwJvLjpLkc", result.Url.ToString());
        }

        [TestMethod]
        public void PayByPhoneTweetsJSON_Get_RetrunTweets()
        {
            var mock = new Mock<ITwitterRepository>();
            List<TwitterStatusModel> pay_by_phone = new List<TwitterStatusModel>{
                       new TwitterStatusModel() {ID = 1111, CreatedAt = new DateTime(2013, 12, 1), User = new TwitterUserModel{ID = 1, Name = "Guy01" }},
                       new TwitterStatusModel() {ID = 2222, CreatedAt = new DateTime(2013, 11, 1), User = new TwitterUserModel{ID = 2, Name = "Guy02" }},
                       new TwitterStatusModel() {ID = 3333, CreatedAt = new DateTime(2013, 10, 1), User = new TwitterUserModel{ID = 3, Name = "Guy03" }}};
            List<TwitterStatusModel> PayByPhone = new List<TwitterStatusModel>{
                       new TwitterStatusModel() {ID = 4444, CreatedAt = new DateTime(2012, 10, 1), User = new TwitterUserModel{ID = 4, Name = "Guy04" }},
                       new TwitterStatusModel() {ID = 5555, CreatedAt = new DateTime(2012, 9, 1) , User = new TwitterUserModel{ID = 5, Name = "Guy05" }}};
            List<TwitterStatusModel> PayByPhone_UK = new List<TwitterStatusModel>{
                       new TwitterStatusModel() {ID = 6666, CreatedAt = new DateTime(2011, 5, 1) , User = new TwitterUserModel{ID = 6, Name = "Guy06" }}};
            mock.Setup(p => p.PayByPhoneTweets(It.IsAny<string>())).Returns((string s) =>
                       s == "pay_by_phone" ? pay_by_phone : s == "PayByPhone" ? PayByPhone : PayByPhone_UK);

            TwitterController tc = new TwitterController(mock.Object);
            ActionResult result = tc.PayByPhoneTweetsJSON() as ActionResult;
            Assert.AreEqual(3, ((AverageByAccountModel)((ViewResult)result).ViewData["pay_by_phone_2weeks"]).Count);
            Assert.AreEqual(2, ((AverageByAccountModel)((ViewResult)result).ViewData["PaybyPhone_2weeks"]).Count);
            Assert.AreEqual(1, ((AverageByAccountModel)((ViewResult)result).ViewData["PaybyPhone_UK_2weeks"]).Count);
        }

        [TestMethod]
        public void PayByPhoneTweetsCountByUserAndAccount_Get_RetrunStatistics()
        {
            var mock = new Mock<ITwitterRepository>();
            List<TwitterStatusModel> pay_by_phone = new List<TwitterStatusModel>{
                       new TwitterStatusModel() {ID = 1111, CreatedAt = new DateTime(2013, 6, 11), User = new TwitterUserModel{ID = 1, Name = "Guy01" }},
                       new TwitterStatusModel() {ID = 2222, CreatedAt = new DateTime(2013, 6, 21), User = new TwitterUserModel{ID = 2, Name = "Guy02" }},
                       new TwitterStatusModel() {ID = 3333, CreatedAt = new DateTime(2013, 6, 15), User = new TwitterUserModel{ID = 3, Name = "Guy03" }}};
            List<TwitterStatusModel> PayByPhone = new List<TwitterStatusModel>{
                       new TwitterStatusModel() {ID = 4444, CreatedAt = new DateTime(2013, 6, 19), User = new TwitterUserModel{ID = 4, Name = "Guy04" }},
                       new TwitterStatusModel() {ID = 5555, CreatedAt = new DateTime(2013, 7, 1) , User = new TwitterUserModel{ID = 5, Name = "Guy05" }}};
            List<TwitterStatusModel> PayByPhone_UK = new List<TwitterStatusModel>{
                       new TwitterStatusModel() {ID = 6666, CreatedAt = new DateTime(2013, 7, 2) , User = new TwitterUserModel{ID = 6, Name = "Guy06" }}};
            mock.Setup(p => p.PayByPhoneTweets(It.IsAny<string>())).Returns((string s) =>
                       s == "pay_by_phone" ? pay_by_phone : s == "PayByPhone" ? PayByPhone : PayByPhone_UK);

            TwitterController tc = new TwitterController(mock.Object);
            ActionResult result = tc.PayByPhoneTweetsCountByUserAndAccount() as ActionResult;
            IList<AverageByUserAccountModel> lst_pay_by_phone = ((IList<AverageByUserAccountModel>)((ViewResult)result).ViewData["pay_by_phone_user_2weeks"]);
            IList<AverageByUserAccountModel> lst_PayByPhone = ((IList<AverageByUserAccountModel>)((ViewResult)result).ViewData["PaybyPhone_user_2weeks"]);
            IList<AverageByUserAccountModel> lst_PayByPhoneUK = ((IList<AverageByUserAccountModel>)((ViewResult)result).ViewData["PaybyPhone_UK_user_2weeks"]);
            Assert.AreEqual(1, lst_pay_by_phone.Count);
            Assert.AreEqual(1, lst_PayByPhone.Count);
            Assert.AreEqual(1, lst_PayByPhoneUK.Count);
        }
    }
}

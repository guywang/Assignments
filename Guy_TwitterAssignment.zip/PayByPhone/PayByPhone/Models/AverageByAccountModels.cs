﻿using System;

namespace PayByPhone.Models
{
    public class AverageByAccountModel
    {
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
        public int Count { get; set; }
    }
}

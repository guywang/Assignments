﻿using System;

namespace PayByPhone.Models
{
    public class TwitterStatusModel
    {
        public DateTime CreatedAt { get; set; }
        public long ID { get; set; }
        public string Text { get; set; }
        public string Source { get; set; }
        public bool Truncated { get; set; }
        public long InReplyToStatusID { get; set; }
        public long InReplyToUserID { get; set; }
        public bool Favorited { get; set; }
        public string InReplyToScreenName { get; set; }
        public TwitterUserModel User { get; set; }
    }
}

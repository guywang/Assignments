﻿
namespace PayByPhone.Models
{
    public class TwitterUserModel
    {
        public long ID { get; set; }
        public string Name { get; set; }
        public string ScreenName { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
        public string ProfileImage { get; set; }
        public string Url { get; set; }
        public bool IsProtected { get; set; }
        public long FollowersCount { get; set; }
        public long FriendsCount { get; set; }
        public string CreatedAt { get; set; }
        public long FavoritesCount { get; set; }
        public bool Verified { get; set; }
        public bool Following { get; set; }
        public long StatusCount { get; set; }
    }
}

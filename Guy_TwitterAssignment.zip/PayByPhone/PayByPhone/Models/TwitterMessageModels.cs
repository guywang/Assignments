﻿using System;

namespace PayByPhone.Models
{
    public class TwitterMessageModel
    {
        public long ID { get; set; }
        public long SenderID { get; set; }
        public long SenderScreenName { get; set; }
        public long RecipientID { get; set; }
        public long RecipientScreenName { get; set; }
        public string Text { get; set; }
        public DateTime CreatedAt { get; set; }
        public TwitterUserModel Sender { get; set; }
        public TwitterUserModel Recipient { get; set; }
    }
}

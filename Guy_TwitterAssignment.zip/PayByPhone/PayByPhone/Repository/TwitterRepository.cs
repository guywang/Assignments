﻿using System;
using System.Collections.Generic;
using PayByPhone.Models;
using System.Net;
using PayByPhone.Helpers;
using TweetSharp;

namespace Twitter.Repository
{
    public class TwitterRepository : ITwitterRepository
    {
        public TwitterUserModel Guy(string screenName)
        {
            // Do the Authenticate
            WebResponse authResponse;
            TwitterHelper.TwitAuthenticateResponse twitAuthResponse = TwitterHelper.AuthorizeUser(out authResponse);

            // Do the timeline
            var timelineFormat = "https://api.twitter.com/1.1/users/show.json?id=living3d";
            var timelineUrl = string.Format(timelineFormat, screenName);
            string timeLineJson = TwitterHelper.GetResponseJSON_V11(timelineUrl, twitAuthResponse.token_type, twitAuthResponse.access_token);

            // Retrieve the Guy's twitter info
            TwitterUserModel guy = TwitterHelper.GetUser(timeLineJson);

            return guy;
        }

        public Uri AuthorizeGuy()
        {
            // Step 1 - Retrieve an OAuth Request Token
            TwitterService service = new TwitterService("LeJMM8QQYjn1UnD8oAwysg", "ZpOWj6Bglo2H5xzoWjPbNgiH3KpX588q11AuN1Pqc0");

            // This is the registered callback URL
            OAuthRequestToken requestToken = service.GetRequestToken("http://www.guywang.biz/VimalAssignment/Twitter/GuyInAction");

            // Step 2 - Redirect to the OAuth Authorization URL
            Uri uri = service.GetAuthorizationUri(requestToken);

            return uri;
        }

        public List<TwitterStatusModel> PayByPhoneTweets(string screenName)
        {
            // Do the Authenticate
            WebResponse authResponse;
            TwitterHelper.TwitAuthenticateResponse twitAuthResponse = TwitterHelper.AuthorizeUser(out authResponse);

            List<TwitterStatusModel> tweets;
            // Retrieve the twitter's tweets on the @pay_by_phone account by JSON format and GET method
            var urlPayByPhone_timelineFormat = String.Format("https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name={0}&include_rts=1&exclude_replies=0&count=20&include_entities=1", screenName);
            string tweetsPayByPhoneJSON = TwitterHelper.GetResponseJSON_V11(urlPayByPhone_timelineFormat, twitAuthResponse.token_type, twitAuthResponse.access_token);
            tweets = TwitterHelper.GetStatusesJSON(tweetsPayByPhoneJSON, true);
            //Sort the result in decending order
            tweets.Sort((x, y) => DateTime.Compare(y.CreatedAt, x.CreatedAt));
            // Save it to be used later by the PayByPhoneTweetsXML view
            return tweets;
        }
    }
}
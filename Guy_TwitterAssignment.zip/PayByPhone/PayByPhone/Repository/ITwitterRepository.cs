﻿using System;
using System.Collections.Generic;
using PayByPhone.Models;

namespace Twitter.Repository
{
    public interface ITwitterRepository
    {
        TwitterUserModel Guy(string userName);
        Uri AuthorizeGuy();
        List<TwitterStatusModel> PayByPhoneTweets(string screenName);
    }
}

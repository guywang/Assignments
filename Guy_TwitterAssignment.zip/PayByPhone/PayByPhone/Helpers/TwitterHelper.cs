﻿using System;
using System.Globalization;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Net;
using System.Xml;
using PayByPhone.Models;
using Newtonsoft.Json.Linq;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.Collections;


namespace PayByPhone.Helpers
{
    public class TwitterHelper
    {
        private static string oAuthConsumerKey = "LeJMM8QQYjn1UnD8oAwysg";
        private static string oAuthConsumerSecret = "ZpOWj6Bglo2H5xzoWjPbNgiH3KpX588q11AuN1Pqc0";
        private static string oAuthUrl = "https://api.twitter.com/oauth2/token";
        private static string screenname = "@PayByPhone";

        // ---------------- Below are works for the assignment from PayByPhone on 2013-07-10
        public static TwitAuthenticateResponse AuthorizeUser(out WebResponse authResponse)
        {
            // Do the Authenticate
            var authHeaderFormat = "Basic {0}";

            var authHeader = string.Format(authHeaderFormat,
                                           Convert.ToBase64String(
                                               Encoding.UTF8.GetBytes(Uri.EscapeDataString(oAuthConsumerKey) + ":" +

                                                                      Uri.EscapeDataString((oAuthConsumerSecret)))

                                               ));
            var postBody = "grant_type=client_credentials";
            HttpWebRequest authRequest = (HttpWebRequest)WebRequest.Create(oAuthUrl);

            authRequest.Headers.Add("Authorization", authHeader);
            authRequest.Method = "POST";
            authRequest.ContentType = "application/x-www-form-urlencoded;charset=UTF-8";
            authRequest.AutomaticDecompression = DecompressionMethods.GZip | DecompressionMethods.Deflate;
            using (Stream stream = authRequest.GetRequestStream())
            {
                byte[] content = ASCIIEncoding.ASCII.GetBytes(postBody);
                stream.Write(content, 0, content.Length);
            }
            authRequest.Headers.Add("Accept-Encoding", "gzip");
            authResponse = authRequest.GetResponse();
            // deserialize into an object
            TwitAuthenticateResponse twitAuthResponse;
            using (authResponse)
            {
                using (var reader = new StreamReader(authResponse.GetResponseStream()))
                {
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    var objectText = reader.ReadToEnd();
                    twitAuthResponse = JsonConvert.DeserializeObject<TwitAuthenticateResponse>(objectText);
                }
            }

            return twitAuthResponse;
        }

        public class TwitAuthenticateResponse
        {
            public string token_type { get; set; }
            public string access_token { get; set; }
        }

        public string HashtableToJson(Hashtable ht)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            serializer.MaxJsonLength = int.MaxValue;
            return serializer.Serialize(ht);
        }

        public static Hashtable JsonToHasshtable(string json)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            serializer.MaxJsonLength = int.MaxValue;
            return serializer.Deserialize<Hashtable>(json);
        }

        public static string GetResponseJSON_V11(string timelineUrl, string token_type, string access_token)
        {
            HttpWebRequest timeLineRequest = (HttpWebRequest)WebRequest.Create(timelineUrl);
            var timelineHeaderFormat = "{0} {1}";
            timeLineRequest.Headers.Add("Authorization", string.Format(timelineHeaderFormat, token_type, access_token));
            timeLineRequest.Method = "Get";
            WebResponse timeLineResponse = timeLineRequest.GetResponse();

            var timeLineJson = string.Empty;
            using (var reader = new StreamReader(timeLineResponse.GetResponseStream()))
            {
                timeLineJson = reader.ReadToEnd();
            }

            return timeLineJson;
        }

        public static TwitterUserModel GetUser(string jsonString)
        {
            Hashtable ht = JsonToHasshtable(jsonString);
            return new TwitterUserModel()
            {
                ID = Convert.ToInt32(ReadHashTableByKey(ht, "id")),
                Name = ReadHashTableByKey(ht, "name"),
                ScreenName = ReadHashTableByKey(ht, "screenname"),
                Location = ReadHashTableByKey(ht, "location"),
                Description = ReadHashTableByKey(ht, "description"),
                ProfileImage = ReadHashTableByKey(ht, "profileImage"),
                Url = ReadHashTableByKey(ht, "url"),
                IsProtected = (ReadHashTableByKey(ht, "isprotected") == "") ? false : Convert.ToBoolean(ReadHashTableByKey(ht, "isprotected")),
                FollowersCount = (ReadHashTableByKey(ht, "followerscount") == "") ? 0 : Convert.ToInt64(ReadHashTableByKey(ht, "followerscount")),
                FriendsCount = (ReadHashTableByKey(ht, "friendscount") == "") ? 0 : Convert.ToInt64(ReadHashTableByKey(ht, "friendscount")),
                CreatedAt = ReadHashTableByKey(ht, "createdat"),
                Following = (ReadHashTableByKey(ht, "following") == "") ? false : Convert.ToBoolean(ReadHashTableByKey(ht, "following")),
                FavoritesCount = (ReadHashTableByKey(ht, "favoritescount") == "") ? 0 : Convert.ToInt64(ReadHashTableByKey(ht, "favoritescount")),
                Verified = (ReadHashTableByKey(ht, "verified") == "") ? false : Convert.ToBoolean(ReadHashTableByKey(ht, "verified")),
                StatusCount = (ReadHashTableByKey(ht, "statuscount") == "") ? 0 : Convert.ToInt64(ReadHashTableByKey(ht, "statuscount")),
            };
        }

        private static string ReadHashTableByKey(Hashtable ht, string key)
        {
            return ht[key] == null ? "" : ht[key].ToString();
        }

        // Load the JSON from the specified uri
        public static string GetResponseJSON(string uri, string username, string password, bool post)
        {
            WebRequest req = WebRequest.Create(new Uri(uri));
            if (post)
                req.Method = "POST";
            else
                req.Method = "GET";
            //req.Headers.Add("Accept", "application/json");
            if ((username != null) && (username.Trim() != String.Empty) && (!String.IsNullOrEmpty(password)))
                req.Credentials = new NetworkCredential(username.Trim(), password);

            string json;
            using (var reader = new StreamReader(req.GetResponse().GetResponseStream(), Encoding.UTF8))
            {
                json = reader.ReadToEnd();
            }
            return json;
        }


        //
        // Load the Status and user instances from the returned JSON sent by twitter
        public static List<TwitterStatusModel> GetStatusesJSON(string json, bool handleUser)
        {
            List<TwitterStatusModel> lst = new List<TwitterStatusModel>();
            JArray jsonDat = JArray.Parse(json);
            TwitterStatusModel theStatus;
            TwitterUserModel theUser;
            string created_at, id, text, source, truncated, inReplyToStatusID, inReplyToUserID, favorited, inReplyToScreenName;
            JObject user;
            for (int x = 0; x < jsonDat.Count; x++)
            {
                JObject tweet = JObject.Parse(jsonDat[x].ToString());
                created_at = tweet["created_at"].ToString();
                id = tweet["id"].ToString();
                text = tweet["text"].ToString();
                source = tweet["source"].ToString();
                truncated = tweet["truncated"].ToString();
                inReplyToStatusID = tweet["in_reply_to_status_id"].ToString();
                inReplyToUserID = tweet["in_reply_to_user_id"].ToString();
                favorited = tweet["favorited"].ToString();
                inReplyToScreenName = tweet["in_reply_to_screen_name"].ToString();
                theStatus = new TwitterStatusModel
                {
                    CreatedAt = ParseTwitterTime(tweet["created_at"].ToString()),
                    ID = HandleNumber(tweet["id"].ToString()),
                    Text = FormatText(tweet["text"].ToString()),
                    Source = FormatText(tweet["source"].ToString()),
                    Truncated = HandleBool(tweet["truncated"].ToString()),
                    InReplyToStatusID = HandleNumber(tweet["in_reply_to_status_id"].ToString()),
                    InReplyToUserID = HandleNumber(tweet["in_reply_to_user_id"].ToString()),
                    Favorited = HandleBool(tweet["favorited"].ToString()),
                    InReplyToScreenName = FormatText(tweet["in_reply_to_screen_name"].ToString()),
                    User = null
                };

                user = JObject.Parse(tweet["user"].ToString());
                theUser = new TwitterUserModel
                {
                    ID = HandleNumber(user["id"].ToString()),
                    Name = FormatText(user["name"].ToString()),
                    ScreenName = FormatText(user["screen_name"].ToString()),
                    Location = FormatText(user["location"].ToString()),
                    Description = FormatText(user["description"].ToString()),
                    ProfileImage = user["profile_image_url"].ToString(),
                    Url = user["url"].ToString(),
                    IsProtected = HandleBool(user["protected"].ToString()),
                    FollowersCount = HandleNumber(user["followers_count"].ToString()),
                    FriendsCount = HandleNumber(user["friends_count"].ToString()),
                    CreatedAt = user["created_at"].ToString(),
                    FavoritesCount = HandleNumber(user["favourites_count"].ToString()),
                    Verified = HandleBool(user["verified"].ToString()),
                    Following = HandleBool(user["following"].ToString()),
                    StatusCount = HandleNumber(user["statuses_count"].ToString())
                };
                if (handleUser)
                    theStatus.User = theUser;
                lst.Add(theStatus);
            }
            return lst;
        }

        //
        // Handle the validity of returned boolean type data
        private static bool HandleBool(string txt)
        {
            return txt == null || txt.ToLower() == "false" ? false : true;
        }

        //
        // Handle the validity of returned number type data
        private static long HandleNumber(string txt)
        {
            return txt == null || txt == String.Empty ? 0 : long.Parse(txt);
        }

        //
        // Handle the validity of returned text type data
        private static string FormatText(string txt)
        {
            return txt == null ? String.Empty : txt.Replace("&lt;", "<").Replace("&gt;", ">");
        }

        //
        // Parse the datetime string from Twitter to the DateTime type for further uses
        public static DateTime ParseTwitterTime(string date)
        {
            const string format = "ddd MMM dd HH:mm:ss zzzz yyyy";
            return DateTime.ParseExact(date, format, CultureInfo.InvariantCulture);
        }

        // ---------------- Above are works for the assignment from PayByPhone on 2013-07-10
    }
}
﻿// Client-Side Events for Delete
function OnBeforeDeleteNA(record) {
    if (confirm("Are you sure you want to delete NA : " + record.CompanyName + " (for " + record.NAID + ") ?") == false)
        return false;
    else
        return true;
}
function OnDeleteNA(record) {
    confirm("The NA : " + record.CompanyName + " (for " + record.NAID + ") was deleted.");
}

// Client-Side Events for Delete
function OnBeforeDeleteLA(record) {
    if (confirm("Are you sure you want to delete LA : " + record.CompanyName + " (for " + record.LAID + ") ?") == false)
        return false;
    else
        return true;
}
function OnDeleteLA(record) {
    confirm("The LA : " + record.CompanyName + " (for " + record.LAID + ") was deleted.");
}

// Client-Side Events for Delete
function OnBeforeDeleteBSO(record) {
    if (confirm("Are you sure you want to delete BSO : " + record.ShopName + " (for " + record.BSOID + ") ?") == false)
        return false;
    else
        return true;
}
function OnDeleteBSO(record) {
    confirm("The BSO : " + record.ShopName + " (for " + record.BSOID + ") was deleted.");
}

// Client-Side Events for Delete
function OnBeforeDeleteProductCategory(record) {
    if (confirm("Are you sure you want to delete Product Category : " + record.ChineseName + " (for " + record.PCID + ") ?") == false)
        return false;
    else
        return true;
}
function OnDeleteProductCategory(record) {
    confirm("The Product Category: " + record.ChineseName + " (for " + record.PCID + ") was deleted.");
}
// Client-Side Events for Delete
function OnBeforeDeleteProduct(record) {
    if (confirm("Are you sure you want to delete Product : " + record.ChineseName + " (for " + record.PID + ") ?") == false)
        return false;
    else
        return true;
}
function OnDeleteProduct(record) {
    confirm("The Product : " + record.ChineseName + " (for " + record.PID + ") was deleted.");
}
// Client-Side Events for Delete
function OnBeforeDeleteProductPrice(record) {
    if (confirm("Are you sure you want to delete Product Price: " + record.ChineseName + " (for " + record.PriceID + ") ?") == false)
        return false;
    else
        return true;
}
function OnDeleteProductPrice(record) {
    confirm("The Product Price: " + record.ChineseName + " (for " + record.PriceID + ") was deleted.");
}
function OnBeforeDeleteGiftPlan(record) {
    if (confirm("Are you sure you want to delete Gift Plan: " + record.GiftPlanID + " ?") == false)
        return false;
    else
        return true;
}
function OnDeleteGiftPlan(record) {
    confirm("The Gift Plan: " + record.GiftPlanID + " was deleted.");
}
function OnBeforeDeletePaymentGateway(record) {
    if (confirm("Are you sure you want to delete Payment Gateway: " + record.PaymentGatewayName +" (for " + record.PID + ") ?") == false)
        return false;
    else
        return true;
}
function OnDeletePaymentGateway(record) {
    confirm("The Payment Gateway: " + record.PaymentGatewayName + " was deleted.");
}

// MS-Chart
var fadingTooltip;
var wnd_height, wnd_width;
var tooltip_height, tooltip_width;
var tooltip_shown = false;
var transparency = 100;
var timer_id = 1;
var tooltiptext;

// override events
window.onload = WindowLoading;
window.onresize = UpdateWindowSize;
document.onmousemove = AdjustToolTipPosition;

function DisplayTooltip(tooltip_text) {
    fadingTooltip.innerHTML = tooltip_text;
    tooltip_shown = (tooltip_text != "") ? true : false;
    if (tooltip_text != "") {
        // Get tooltip window height
        tooltip_height = (fadingTooltip.style.pixelHeight) ? fadingTooltip.style.pixelHeight : fadingTooltip.offsetHeight;
        transparency = 0;
        ToolTipFading();
    }
    else {
        clearTimeout(timer_id);
        fadingTooltip.style.visibility = "hidden";
    }
}

function AdjustToolTipPosition(e) {
    if (tooltip_shown) {
        // Depending on IE/Firefox, find out what object to use to find mouse position
        var ev;
        if (e)
            ev = e;
        else
            ev = event;

        fadingTooltip.style.visibility = "visible";
        offset_y = (ev.clientY + tooltip_height - document.body.scrollTop + 30 >= wnd_height) ? -15 - tooltip_height : 20;
        fadingTooltip.style.left = Math.min(wnd_width - tooltip_width - 10, Math.max(3, ev.clientX + 6)) + document.body.scrollLeft + 'px';
        fadingTooltip.style.top = ev.clientY + offset_y + document.body.scrollTop + 'px';
    }
}

function WindowLoading() {
    fadingTooltip = document.getElementById('fadingTooltip');

    // Get tooltip  window width				
    tooltip_width = (fadingTooltip.style.pixelWidth) ? fadingTooltip.style.pixelWidth : fadingTooltip.offsetWidth;

    // Get tooltip window height
    tooltip_height = (fadingTooltip.style.pixelHeight) ? fadingTooltip.style.pixelHeight : fadingTooltip.offsetHeight;

    UpdateWindowSize();
}

function ToolTipFading() {
    if (transparency <= 100) {
        fadingTooltip.style.filter = "alpha(opacity=" + transparency + ")";
        fadingTooltip.style.opacity = transparency / 100;
        transparency += 5;
        timer_id = setTimeout('ToolTipFading()', 35);
    }
}

function UpdateWindowSize() {
    wnd_height = document.body.clientHeight;
    wnd_width = document.body.clientWidth;
}
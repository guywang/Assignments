﻿function FP_getObjectByID(id, o) {//v1.0
    var c, el, els, f, m, n;
    if (!o)
        o = document;
    if (o.getElementById)
        el = o.getElementById(id);
    else if (o.layers)
        c = o.layers;
    else if (o.all)
        el = o.all[id];
    if (el)
        return el;
    if (o.id == id || o.name == id)
        return o;
    if (o.childNodes)
        c = o.childNodes;
    if (c)
        for (n = 0; n < c.length; n++) {
            el = FP_getObjectByID(id, c[n]);
            if (el)
                return el;
        }
    f = o.forms;
    if (f)
        for (n = 0; n < f.length; n++) {
            els = f[n].elements;
            for (m = 0; m < els.length; m++) {
                el = FP_getObjectByID(id, els[n]);
                if (el)
                    return el;
            }
        }
    return null;
}

function FP_changePropRestore() {//v1.0
    var d = document, x;
    if (d.$cpe) {
        for (i = 0; i < d.$cpe.length; i++) {
            x = d.$cpe[i];
            if (x.v == "")
                x.v = "";
            eval("x." + x.n + "=x.v");
        }
        d.$cpe = null;
    }
}

function FP_changeProp() {//v1.0
    var args = arguments, d = document, i, j, id = args[0], o = FP_getObjectByID(id), s, ao, v, x;
    d.$cpe = new Array();
    if (o)
        for (i = 2; i < args.length; i += 2) {
            v = args[i + 1]; s = "o";
            ao = args[i].split(".");
            for (j = 0; j < ao.length; j++) {
                s += "." + ao[j];
                if (null == eval(s)) {
                    s = null; break;
                }
            }
            x = new Object;
            x.o = o; x.n = new Array();
            x.v = new Array();
            x.n[x.n.length] = s;
            eval("x.v[x.v.length]=" + s);
            d.$cpe[d.$cpe.length] = x;
            if (s)
                eval(s + "=v");
        }
}

﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Web.Mvc;
using PayByPhone.Models;
using Twitter.Repository;

namespace PayByPhone.Controllers
{
    public class TwitterController : Controller
    {
        ITwitterRepository _tr;

        public TwitterController()
        {
            _tr = new TwitterRepository();
        }

        public TwitterController(ITwitterRepository tr)
        {
            _tr = tr;
        }

        //
        // GET: /Twitter/
        public ActionResult Index()
        {
            ViewBag.Message = "Guy's accomplishment on the Twitter assignment.";

            return View();
        }

        //
        // GET: /Twitter/Guy
        public ActionResult Guy(string screenName = "@PayByPhone")
        {
            TwitterUserModel guy = _tr.Guy(screenName);
            // Display the result to the users
            return View(guy);
        }

        //
        // GET: /Twitter/AuthorizeGuy
        public ActionResult AuthorizeGuy()
        {
            Uri uri = _tr.AuthorizeGuy();
            return new RedirectResult(uri.ToString(), false /*permanent*/);
        }

        //
        // GET: /Twitter/PayByPhoneTweetsJSON
        public ActionResult PayByPhoneTweetsJSON()
        {
            List<TwitterStatusModel>[] tweets = new List<TwitterStatusModel>[3];

            tweets[0] = _tr.PayByPhoneTweets("pay_by_phone");
            ViewData["pay_by_phone_2weeks"] = GroupByDateTime(tweets[0], System.DateTime.Now.AddDays(-14), System.DateTime.Now);

            tweets[1] = _tr.PayByPhoneTweets("PayByPhone");
            ViewData["PaybyPhone_2weeks"] = GroupByDateTime(tweets[1], System.DateTime.Now.AddDays(-14), System.DateTime.Now);

            tweets[2] = _tr.PayByPhoneTweets("PayByPhone_UK");
            ViewData["PaybyPhone_UK_2weeks"] = GroupByDateTime(tweets[2], System.DateTime.Now.AddDays(-14), System.DateTime.Now);

            return View(tweets);
        }

        //
        // GET: /Twitter/PayByPhoneTweetsCountByUserAndAccount
        public ActionResult PayByPhoneTweetsCountByUserAndAccount()
        {
            List<TwitterStatusModel>[] tweets = new List<TwitterStatusModel>[3];

            tweets[0] = _tr.PayByPhoneTweets("pay_by_phone");
            ViewData["pay_by_phone_user_2weeks"] = GroupByUserDateTime(tweets[0], System.DateTime.Now.AddDays(-14), System.DateTime.Now);

            tweets[1] = _tr.PayByPhoneTweets("PayByPhone");
            ViewData["PaybyPhone_user_2weeks"] = GroupByUserDateTime(tweets[1], System.DateTime.Now.AddDays(-14), System.DateTime.Now);

            tweets[2] = _tr.PayByPhoneTweets("PayByPhone_UK");
            ViewData["PaybyPhone_UK_user_2weeks"] = GroupByUserDateTime(tweets[2], System.DateTime.Now.AddDays(-14), System.DateTime.Now);

            // Display the final results from three twitter accounts to the users
            return View();
        }

        //
        // Count the number of tweets in a specified datetime window
        private AverageByAccountModel GroupByDateTime(List<TwitterStatusModel> tweets, DateTime start, DateTime end)
        {
            TimeSpan zero = start.TimeOfDay; 
            TimeSpan range = end.Subtract(start); 
            // The actual query which does to trick     
            var query = tweets.Where(d => d.CreatedAt.Subtract(zero).TimeOfDay < range);
            return new AverageByAccountModel
            {
                Start = start,
                End = end,
                Count = query.Count()
            };
        }

        //
        // Count the number of tweets by users in a specified datetime window
        private IList<AverageByUserAccountModel> GroupByUserDateTime(List<TwitterStatusModel> tweets, DateTime start, DateTime end)
        {
            List<AverageByUserAccountModel> theUserStatuses = new List<AverageByUserAccountModel>();
            TimeSpan zero = start.TimeOfDay;
            TimeSpan range = end.Subtract(start);
            // The actual query which does to trick     
            var query = tweets.Where(d => d.CreatedAt.Subtract(zero).TimeOfDay < range).GroupBy(d => d.InReplyToScreenName);
            foreach (var eachUserStatus in query)
            {
                theUserStatuses.Add(new AverageByUserAccountModel
                {
                    Start = start,
                    End = end,
                    Count = eachUserStatus.Count(),
                    Name = string.IsNullOrEmpty(eachUserStatus.Key) ? "Anonymous" : eachUserStatus.Key
                });
            }
            return theUserStatuses;
        }
    }
}
